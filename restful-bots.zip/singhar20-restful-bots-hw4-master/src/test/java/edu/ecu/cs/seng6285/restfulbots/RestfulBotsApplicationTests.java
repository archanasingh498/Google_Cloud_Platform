package edu.ecu.cs.seng6285.restfulbots;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulBotsApplicationTests {

	@Test
	void contextLoads() {
	}

}

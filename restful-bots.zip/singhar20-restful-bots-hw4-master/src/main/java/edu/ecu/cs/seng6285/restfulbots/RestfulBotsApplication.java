package edu.ecu.cs.seng6285.restfulbots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulBotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulBotsApplication.class, args);
	}

}
